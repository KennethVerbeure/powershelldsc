configuration CreateADDNS
{
   param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,
        [Parameter(Mandatory)]
        [String]$MachineName,
        [Parameter(Mandatory)]
        [PSCredential]$AdminCreds
    )
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement
    Import-DscResource -Module PowerShellAccessControl
    Import-DscResource -Name MSFT_xSmbShare
    [PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential("${DomainName}\$($AdminCreds.UserName)", $AdminCreds.Password)
    [String]$sharePath = 'C:\awingu\Users'

    Node localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        WindowsFeature DNS
        {
            Ensure = 'Present'
            Name = 'DNS'
        }

        WindowsFeature DNSTools
        {
            Ensure = 'Present'
            Name = 'RSAT-DNS-Server'
            DependsOn = '[WindowsFeature]DNS'
        }

        WindowsFeature ADDSInstall
        {
            Ensure = 'Present'
            Name = 'AD-Domain-Services'
            DependsOn = '[WindowsFeature]DNSTools'

        }

        WindowsFeature ADDSTools
        {
            Ensure = 'Present'
            Name = 'RSAT-AD-Tools'
            IncludeAllSubFeature = $true
            DependsOn = '[WindowsFeature]ADDSInstall'
        }

        xADDomain AddDomain
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DependsOn = '[WindowsFeature]ADDSInstall'
        }

        xComputer NewName
        {
            Name = $MachineName
            Credential = $DomainCreds
            DomainName = $DomainName
        }

        File AwinguUsersFolder {
            Ensure = "Present"
            Type = "Directory"
            DestinationPath = $sharePath
        }

        cAccessControlEntry EveryoneModifyTestFolder {
            Ensure = "Present"
            Path = $sharePath
            AceType = "Allow"
            ObjectType = "Directory"
            AccessMask = New-PacAccessMask -FolderRights FullControl
            Principal = "Everyone"
            DependsOn = "[File]AwinguUsersFolder"
        }

        xSmbShare CreateShare
        {
            Ensure = 'Present'
            Name = 'Users'
            Path = $sharePath
            FullAccess = 'Everyone'
            Description = 'This will be the home drive for awingu users'
            DependsOn =  "[File]AwinguUsersFolder"
        }
    }
}