configuration CreateADDNS
{
   param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds
    )
    Import-DscResource -ModuleName xActiveDirectory
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node Localhost
    {
        WindowsFeature DNS
        {
            Ensure = 'Present'
            Name = 'DNS'
        }
        WindowsFeature DNSTools
        {
            Ensure = 'Present'
            Name = 'RSAT-DNS-Server'
            DependsOn = '[WindowsFeature]DNS'
        }

        WindowsFeature ADDSInstall
        {
            Ensure = 'Present'
            Name = 'AD-Domain-Services'
            DependsOn = '[WindowsFeature]DNSTools'

        }
        WindowsFeature ADDSTools
        {
            Ensure = 'Present'
            Name = 'RSAT-AD-Tools'
            DependsOn = '[WindowsFeature]ADDSInstall'
            IncludeAllSubFeature = $true
        }
        xADDomain FirstDS
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DependsOn = '[WindowsFeature]ADDSInstall'
        }
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
    }
}