configuration CreateADDNS
{
   param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,
        [Parameter(Mandatory)]
        [String]$MachineName,
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCreds
    )
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential("${DomainName}\$($AdminCreds.UserName)", $AdminCreds.Password)

    Node Localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
        xComputer NewName
        {
            Name = $MachineName
        }
        WindowsFeature DNS
        {
            Ensure = 'Present'
            Name = 'DNS'
            DependsOn = '[xComputer]NewName'
        }
        WindowsFeature DNSTools
        {
            Ensure = 'Present'
            Name = 'RSAT-DNS-Server'
            DependsOn = '[WindowsFeature]DNS'
        }

        WindowsFeature ADDSInstall
        {
            Ensure = 'Present'
            Name = 'AD-Domain-Services'
            DependsOn = '[WindowsFeature]DNSTools'

        }
        WindowsFeature ADDSTools
        {
            Ensure = 'Present'
            Name = 'RSAT-AD-Tools'
            DependsOn = '[WindowsFeature]ADDSInstall'
            IncludeAllSubFeature = $true
        }
        xADDomain AddDomain
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DependsOn = '[WindowsFeature]ADDSInstall'
        }
    }
}