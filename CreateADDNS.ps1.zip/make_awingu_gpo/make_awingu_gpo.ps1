﻿param(
    [Parameter(Mandatory=$True)]
    [string]$domain
)

Foreach ($piece in $domain.split('.'))
{
    $baseDN += 'dc=' + $piece + ','
}

$baseDN = $baseDN.Substring(0, $baseDN.Length -1)

import-gpo -BackupGpoName Awingu-gpo -TargetName AwinguGPO -path C:\Users\kenneth\Desktop -CreateIfNeeded -Domain $domain

New-GPLink -Target $baseDN -Domain $domain -Name AwinguGPO -Enforced Yes