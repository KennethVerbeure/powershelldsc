configuration CreateAppServer
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DnsServerAddress,
        [Parameter(Mandatory)]
        [String]$MachineName,
        [Parameter(Mandatory)]
        [String]$DomainName,
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCreds
    )
    Import-DscResource -Module xNetworking, xComputerManagement
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential("${DomainName}\$($AdminCreds.UserName)", $AdminCreds.Password)

    Node localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
        xDnsServerAddress DnsServerAddress
        {
            Address = $DnsServerAddress
            InterfaceAlias = 'Ethernet'
            AddressFamily  = 'IPv4'
        }
        xComputer JoinDomain
        {
            Name = $MachineName
            DomainName = $DomainName
            Credential = $DomainCreds
        }
    }
}
